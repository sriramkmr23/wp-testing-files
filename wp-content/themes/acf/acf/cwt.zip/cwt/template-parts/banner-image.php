<?php //if( get_sub_field( 'image-include' ) == 'yes' ) :?>

<!-- Start Image Content -->
<section class="image stmt-1 stmb-1">
                <figure class="figure">

                    <img src="<?php echo get_sub_field( 'banner-image' )[ 'url' ]; ?>"
                        class="figure-img img-fluid"
                        alt="<?php echo get_sub_field( 'banner-image' )[ 'alt' ]; ?>">

                </figure>

</section>
<!-- ENd Image Content -->

<?php// endif; ?>